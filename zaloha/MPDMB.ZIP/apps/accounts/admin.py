from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from django.contrib.auth.forms import AdminUserCreationForm, UserChangeForm
from django.urls import reverse
from django.utils.html import format_html

from .models import User
from .staff_sync import ensure_staff_for_admin_role


_FIELD_LABELS = {
    "username": "Uživatelské jméno",
    "password": "Heslo",
    "first_name": "Jméno",
    "last_name": "Příjmení",
    "email": "E-mail",
    "is_staff": "Přístup do administrace",
    "is_active": "Aktivní",
    "is_superuser": "Superuživatel",
    "groups": "Skupiny",
    "user_permissions": "Uživatelská oprávnění",
    "last_login": "Poslední přihlášení",
    "date_joined": "Datum registrace",
    "employee_link": "Zaměstnanec",
}

_FIELD_HELP = {
    "is_staff": (
        "Určuje, zda se uživatel může přihlásit do administrace. "
        "Při zařazení do skupiny administrátor se zapne automaticky."
    ),
    "is_active": (
        "Určuje, zda je účet aktivní. Odškrtněte místo mazání účtu."
    ),
    "is_superuser": (
        "Uživatel má všechna oprávnění bez explicitního přiřazení."
    ),
    "groups": (
        "Skupiny, do kterých uživatel patří. Získá oprávnění těchto skupin. "
        "Skupina administrátor zároveň zapne přístup do administrace."
    ),
    "user_permissions": "Specifická oprávnění pro tohoto uživatele.",
}


def _apply_czech_labels(form):
    for name, label in _FIELD_LABELS.items():
        if name in form.fields:
            form.fields[name].label = label
    for name, help_text in _FIELD_HELP.items():
        if name in form.fields:
            form.fields[name].help_text = help_text


class CzechUserChangeForm(UserChangeForm):
    class Meta(UserChangeForm.Meta):
        model = User

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _apply_czech_labels(self)


class CzechUserCreationForm(AdminUserCreationForm):
    class Meta(AdminUserCreationForm.Meta):
        model = User
        fields = ("username", "is_active", "is_staff", "groups")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _apply_czech_labels(self)
        if "password1" in self.fields:
            self.fields["password1"].label = "Heslo"
        if "password2" in self.fields:
            self.fields["password2"].label = "Potvrzení hesla"
        if "is_active" in self.fields:
            self.fields["is_active"].initial = True


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    form = CzechUserChangeForm
    add_form = CzechUserCreationForm
    list_display = (
        "username",
        "email",
        "first_name",
        "last_name",
        "is_staff",
        "is_active",
    )
    list_filter = ("is_staff", "is_superuser", "is_active", "groups")
    search_fields = ("username", "first_name", "last_name", "email")
    ordering = ("username",)
    filter_horizontal = ("groups", "user_permissions")
    readonly_fields = ("employee_link", "last_login", "date_joined")

    fieldsets = (
        (None, {"fields": ("username", "password")}),
        (
            "Osobní údaje",
            {
                "description": (
                    "Jméno, příjmení a e-mail se berou ze zaměstnance. "
                    "U zaměstnance vyplňte údaje a v poli Účet přiřaďte "
                    "tohoto uživatele — po uložení se sem zkopírují."
                ),
                "fields": ("employee_link",),
            },
        ),
        (
            "Oprávnění",
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                )
            },
        ),
        ("Důležitá data", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "username",
                    "usable_password",
                    "password1",
                    "password2",
                    "is_active",
                    "is_staff",
                    "groups",
                ),
            },
        ),
    )

    @admin.display(description="Zaměstnanec")
    def employee_link(self, obj):
        if obj is None or not obj.pk:
            return "—"
        employee = getattr(obj, "employee_profile", None)
        if employee is None:
            return (
                "Nepřiřazen — jméno nastavte u zaměstnance a v poli Účet "
                "vyberte tento účet."
            )
        url = reverse("admin:employees_employee_change", args=[employee.pk])
        return format_html('<a href="{}">{}</a>', url, employee)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        for name, label in _FIELD_LABELS.items():
            if name in form.base_fields:
                form.base_fields[name].label = label
        for name, help_text in _FIELD_HELP.items():
            if name in form.base_fields:
                form.base_fields[name].help_text = help_text
        return form

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        ensure_staff_for_admin_role(form.instance)
