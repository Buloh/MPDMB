from django.contrib import admin

from .models import (
    EmployeeLeaveSettings,
    LeaveEntitlement,
    LeavePolicySettings,
)


@admin.register(LeavePolicySettings)
class LeavePolicySettingsAdmin(admin.ModelAdmin):
    list_display = (
        "__str__",
        "default_weeks_wage",
        "default_weeks_salary",
        "allow_carryover",
        "enforce_continuous_block",
        "continuous_count_holidays",
        "updated_at",
    )
    fields = (
        "default_weeks_wage",
        "default_weeks_salary",
        "carryover_min_weeks_kept",
        "continuous_min_days",
        "continuous_count_holidays",
        "allow_carryover",
        "enforce_continuous_block",
        "prefer_older_entitlement",
        "warn_unused_carryover",
        "block_overlap_with_work_shifts",
        "allow_half_day",
        "updated_at",
    )
    readonly_fields = ("updated_at",)

    def has_add_permission(self, request):
        return not LeavePolicySettings.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False

    def changelist_view(self, request, extra_context=None):
        obj = LeavePolicySettings.load()
        from django.shortcuts import redirect
        from django.urls import reverse

        return redirect(
            reverse(
                f"admin:{obj._meta.app_label}_{obj._meta.model_name}_change",
                args=[obj.pk],
            )
        )


@admin.register(EmployeeLeaveSettings)
class EmployeeLeaveSettingsAdmin(admin.ModelAdmin):
    list_display = (
        "employment",
        "extra_weeks",
        "allow_carryover",
        "allow_half_day",
        "enforce_continuous_block",
    )
    search_fields = (
        "employment__employee__last_name",
        "employment__employee__internal_number",
    )


@admin.register(LeaveEntitlement)
class LeaveEntitlementAdmin(admin.ModelAdmin):
    list_display = (
        "employment",
        "year",
        "accrued_minutes",
        "entitled_minutes",
        "carried_in_minutes",
        "planned_minutes",
        "taken_minutes",
        "must_use_by",
    )
    list_filter = ("year",)
    search_fields = (
        "employment__employee__last_name",
        "employment__employee__internal_number",
    )
    readonly_fields = ("source_note", "updated_at")
    fields = (
        "employment",
        "year",
        "accrued_minutes",
        "entitled_minutes",
        "carried_in_minutes",
        "planned_minutes",
        "taken_minutes",
        "must_use_by",
        "source_note",
        "updated_at",
    )
