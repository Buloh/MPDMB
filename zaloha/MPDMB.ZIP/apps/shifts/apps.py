from django.apps import AppConfig


class ShiftsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.shifts"
    label = "shifts"
    verbose_name = "Směny"
