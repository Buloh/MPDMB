"""Testy matic oprávnění rolí."""

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.test import TestCase

from apps.accounts.permission_labels import (
    delete_orphaned_content_types,
    refresh_permission_names,
)
from apps.accounts.role_permissions import (
    permission_keys_for_role,
    sync_role_group_permissions,
)
from apps.accounts.roles import ROLE_ADMIN, ROLE_MANAGER, ROLE_EMPLOYEE, ROLE_READER
from apps.core.dashboard import can_manage_directory
from apps.shifts.services import can_manage_shift_plan


class RolePermissionsTests(TestCase):
    def test_sync_admin_gets_all_permissions(self):
        counts = sync_role_group_permissions()
        total = Permission.objects.count()
        self.assertEqual(counts[ROLE_ADMIN], total)
        self.assertGreater(counts[ROLE_ADMIN], counts[ROLE_MANAGER])
        self.assertGreater(counts[ROLE_MANAGER], counts[ROLE_EMPLOYEE])
        self.assertEqual(counts[ROLE_EMPLOYEE], counts[ROLE_READER])

        admin = Group.objects.get(name=ROLE_ADMIN)
        manager = Group.objects.get(name=ROLE_MANAGER)
        admin_keys = {
            f"{p.content_type.app_label}.{p.codename}"
            for p in admin.permissions.select_related("content_type")
        }
        manager_keys = {
            f"{p.content_type.app_label}.{p.codename}"
            for p in manager.permissions.select_related("content_type")
        }
        self.assertEqual(admin.permissions.count(), total)
        self.assertIn("accounts.change_user", admin_keys)
        self.assertNotIn("accounts.change_user", manager_keys)
        self.assertIn("activities.export_activity_plan", admin_keys)
        self.assertIn("activities.export_activity_plan", manager_keys)
        self.assertTrue(manager_keys < admin_keys)

    def test_staff_without_role_cannot_manage(self):
        User = get_user_model()
        staff = User.objects.create_user(
            username="bare_staff",
            password="x",
            is_staff=True,
            is_superuser=False,
        )
        self.assertFalse(can_manage_directory(staff))
        self.assertFalse(can_manage_shift_plan(staff))

        Group.objects.get_or_create(name=ROLE_MANAGER)
        sync_role_group_permissions()
        staff.groups.add(Group.objects.get(name=ROLE_MANAGER))
        staff = User.objects.get(pk=staff.pk)
        self.assertTrue(can_manage_directory(staff))
        self.assertTrue(can_manage_shift_plan(staff))

    def test_permission_keys_employee_are_view_only(self):
        keys = permission_keys_for_role(ROLE_EMPLOYEE)
        self.assertTrue(keys)
        for key in keys:
            self.assertIn(".view_", key)
            self.assertNotIn(".add_", key)
            self.assertNotIn(".change_", key)
            self.assertNotIn(".delete_", key)

    def test_refresh_permission_names_are_czech(self):
        refresh_permission_names()
        session_view = Permission.objects.get(
            content_type__app_label="sessions", codename="view_session"
        )
        self.assertTrue(session_view.name.startswith("Zobrazit: "))
        self.assertNotIn("Can view", session_view.name)
        self.assertNotIn("content type", session_view.name.lower())

        ct_view = Permission.objects.get(
            content_type__app_label="contenttypes",
            codename="view_contenttype",
        )
        self.assertTrue(ct_view.name.startswith("Zobrazit: "))
        self.assertNotIn("content type", ct_view.name.lower())

        export = Permission.objects.get(codename="export_activity_plan")
        self.assertEqual(export.name, "Exportovat plán činností")

    def test_delete_orphaned_content_types(self):
        orphan = ContentType.objects.create(
            app_label="core", model="mealallowancesettings_orphan_test"
        )
        Permission.objects.create(
            content_type=orphan,
            codename="view_mealallowancesettings_orphan_test",
            name="Can view orphan",
        )
        deleted = delete_orphaned_content_types()
        self.assertGreaterEqual(deleted, 1)
        self.assertFalse(ContentType.objects.filter(pk=orphan.pk).exists())


class AdminStaffAutoTests(TestCase):
    def test_admin_group_sets_is_staff(self):
        User = get_user_model()
        user = User.objects.create_user(
            username="future_admin",
            password="x",
            is_staff=False,
            is_superuser=False,
        )
        group, _ = Group.objects.get_or_create(name=ROLE_ADMIN)
        user.groups.add(group)
        user.refresh_from_db()
        self.assertTrue(user.is_staff)

    def test_manager_group_does_not_set_is_staff(self):
        User = get_user_model()
        user = User.objects.create_user(
            username="future_mgr",
            password="x",
            is_staff=False,
            is_superuser=False,
        )
        group, _ = Group.objects.get_or_create(name=ROLE_MANAGER)
        user.groups.add(group)
        user.refresh_from_db()
        self.assertFalse(user.is_staff)
