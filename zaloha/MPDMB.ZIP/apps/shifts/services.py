"""Služby pro plán směn: překryvy, verze, publikace, matice."""

from __future__ import annotations

from datetime import date, datetime, timedelta

from django.contrib.auth.models import AbstractBaseUser
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Prefetch, QuerySet
from django.utils import timezone

from apps.accounts.roles import ROLE_ADMIN, ROLE_MANAGER
from apps.core.models import AuditEvent
from apps.employees.models import BalancingPeriod, Employee, WorkTimeProfile
from apps.employees.services import employment_for_day
from apps.workplaces.models import EmployeeWorkplace, Workplace

from .fund import (
    calendar_month_fund,
    daily_minutes_for_employee,
    dynamic_balancing_target_minutes,
    employee_month_fund,
    format_hours,
    month_day_list,
    resolve_daily_fund_minutes,
)
from .holidays import holidays_for_year
from .models import (
    WEEKDAY_LABELS_SHORT,
    EmployeeScheduleAssignment,
    ScheduleTemplate,
    Shift,
    ShiftType,
)


class ShiftConflictError(ValidationError):
    """Konflikt souběžné úpravy nebo překryvu směn."""


MISSING_EMPLOYMENT_SHIFT_MSG = (
    "Nelze naplánovat směnu: chybí aktivní pracovní vztah k datu {day}. "
    "Doplňte den nástupu na kartě zaměstnance."
)


def _require_employment_for_day(employee: Employee, day: date) -> None:
    if employment_for_day(employee, day) is None:
        raise ValidationError(
            MISSING_EMPLOYMENT_SHIFT_MSG.format(day=day.strftime("%d.%m.%Y"))
        )


def _audit(user, operation: str, shift: Shift, detail: str = "") -> None:
    AuditEvent.objects.create(
        user=user if getattr(user, "is_authenticated", False) else None,
        operation=operation,
        object_type="Shift",
        object_id=str(shift.pk),
        detail=detail,
    )


def _group_names(user: AbstractBaseUser) -> set[str]:
    return set(user.groups.values_list("name", flat=True))


def can_manage_shift_plan(user: AbstractBaseUser) -> bool:
    if not getattr(user, "is_authenticated", False):
        return False
    if user.is_superuser:
        return True
    names = _group_names(user)
    return ROLE_ADMIN in names or ROLE_MANAGER in names


def employees_visible_for_shift_plan(user: AbstractBaseUser) -> QuerySet[Employee]:
    if not getattr(user, "is_authenticated", False):
        return Employee.objects.none()
    if can_manage_shift_plan(user):
        return Employee.objects.filter(is_active=True).order_by(
            "last_name", "first_name"
        )
    return Employee.objects.filter(user=user, is_active=True).order_by(
        "last_name", "first_name"
    )


def find_overlapping_shifts(
    *,
    employee_id: int,
    starts_at,
    ends_at,
    exclude_pk: int | None = None,
) -> list[Shift]:
    qs = Shift.objects.filter(employee_id=employee_id).exclude(
        status=Shift.Status.CANCELLED
    )
    if exclude_pk:
        qs = qs.exclude(pk=exclude_pk)
    qs = qs.filter(starts_at__lt=ends_at, ends_at__gt=starts_at)
    return list(qs.select_related("workplace", "shift_type").order_by("starts_at"))


def _lock_employee_shifts(employee_id: int) -> None:
    list(
        Shift.objects.select_for_update()
        .filter(employee_id=employee_id)
        .exclude(status=Shift.Status.CANCELLED)
        .only("id")
    )


def _ensure_no_overlap(shift: Shift) -> None:
    overlaps = find_overlapping_shifts(
        employee_id=shift.employee_id,
        starts_at=shift.starts_at,
        ends_at=shift.ends_at,
        exclude_pk=shift.pk,
    )
    if overlaps:
        first = overlaps[0]
        raise ShiftConflictError(
            "Zaměstnanec má v tomto čase jinou směnu "
            f"({first.starts_at:%d.%m.%Y %H:%M}–{first.ends_at:%d.%m.%Y %H:%M}, "
            f"{first.workplace})."
        )


def apply_shift_type(shift: Shift, shift_type: ShiftType, day: date) -> Shift:
    starts, ends = shift_type.bounds_for_date(day)
    shift.shift_type = shift_type
    shift.starts_at = starts
    shift.ends_at = ends
    return shift


@transaction.atomic
def create_shift(*, user, shift: Shift) -> Shift:
    if shift.ends_at <= shift.starts_at:
        raise ValidationError({"ends_at": "Konec směny musí být později než začátek."})
    day = timezone.localtime(shift.starts_at).date()
    _require_employment_for_day(shift.employee, day)
    shift.status = shift.status or Shift.Status.DRAFT
    shift.version = 1
    _lock_employee_shifts(shift.employee_id)
    _ensure_no_overlap(shift)
    shift.save()
    _audit(user, "shift_create", shift, detail=shift.status)
    return shift


@transaction.atomic
def update_shift(*, user, shift: Shift, expected_version: int) -> Shift:
    locked = (
        Shift.objects.select_for_update()
        .select_related("employee", "workplace", "shift_type")
        .get(pk=shift.pk)
    )
    if locked.version != expected_version:
        raise ShiftConflictError(
            "Směnu mezitím upravil někdo jiný. Obnovte stránku a zkuste znovu."
        )
    if locked.status == Shift.Status.CANCELLED:
        raise ValidationError("Zrušenou směnu nelze upravit.")
    if shift.ends_at <= shift.starts_at:
        raise ValidationError({"ends_at": "Konec směny musí být později než začátek."})

    locked.employee = shift.employee
    locked.workplace = shift.workplace
    locked.shift_type = shift.shift_type
    locked.starts_at = shift.starts_at
    locked.ends_at = shift.ends_at
    locked.note = shift.note
    day = timezone.localtime(locked.starts_at).date()
    _require_employment_for_day(locked.employee, day)
    _lock_employee_shifts(locked.employee_id)
    _ensure_no_overlap(locked)
    locked.version = locked.version + 1
    locked.save()
    _audit(user, "shift_update", locked, detail=f"v{locked.version}")
    return locked


MAX_SHIFTS_PER_DAY = 12


def _shifts_on_calendar_day(employee: Employee, day: date):
    tz = timezone.get_current_timezone()
    start = timezone.make_aware(datetime.combine(day, datetime.min.time()), tz)
    end = timezone.make_aware(
        datetime.combine(day + timedelta(days=1), datetime.min.time()), tz
    )
    return (
        Shift.objects.filter(employee=employee)
        .exclude(status=Shift.Status.CANCELLED)
        .filter(starts_at__lt=end, ends_at__gt=start)
    )


@transaction.atomic
def assign_shift_cell(
    *,
    user,
    employee: Employee,
    workplace: Workplace,
    day: date,
    shift_type: ShiftType,
    publish: bool = False,
) -> Shift:
    _require_employment_for_day(employee, day)
    if not shift_type.applies_on_holiday and day in holidays_for_year(day.year):
        raise ValidationError("Tento typ směny není povolen ve svátek.")
    starts, ends = shift_type.bounds_for_date(day)
    _lock_employee_shifts(employee.pk)
    day_shifts = list(
        _shifts_on_calendar_day(employee, day)
        .select_for_update()
        .select_related("shift_type")
        .order_by("starts_at")
    )
    same_type = next(
        (s for s in day_shifts if s.shift_type_id == shift_type.pk),
        None,
    )
    status = Shift.Status.PUBLISHED if publish else Shift.Status.DRAFT
    if same_type:
        same_type.workplace = workplace
        same_type.shift_type = shift_type
        same_type.starts_at = starts
        same_type.ends_at = ends
        same_type.status = status
        same_type.version = same_type.version + 1
        _ensure_no_overlap(same_type)
        same_type.save()
        _audit(user, "shift_cell_update", same_type, detail=shift_type.code)
        return same_type

    if len(day_shifts) >= MAX_SHIFTS_PER_DAY:
        raise ValidationError(
            f"V jednom dni lze mít nejvýše {MAX_SHIFTS_PER_DAY} směn."
        )

    overlap = next(
        (s for s in day_shifts if s.starts_at < ends and s.ends_at > starts),
        None,
    )
    if overlap:
        raise ShiftConflictError(
            "Nová směna se časově překrývá s "
            f"{overlap.display_code} "
            f"({overlap.starts_at:%H:%M}–{overlap.ends_at:%H:%M})."
        )

    shift = Shift(
        employee=employee,
        workplace=workplace,
        shift_type=shift_type,
        starts_at=starts,
        ends_at=ends,
        status=status,
        version=1,
    )
    _ensure_no_overlap(shift)
    shift.save()
    _audit(user, "shift_cell_create", shift, detail=shift_type.code)
    return shift


@transaction.atomic
def publish_shift(*, user, shift: Shift, expected_version: int) -> Shift:
    locked = Shift.objects.select_for_update().get(pk=shift.pk)
    if locked.version != expected_version:
        raise ShiftConflictError(
            "Směnu mezitím upravil někdo jiný. Obnovte stránku a zkuste znovu."
        )
    if locked.status == Shift.Status.CANCELLED:
        raise ValidationError("Zrušenou směnu nelze publikovat.")
    locked.status = Shift.Status.PUBLISHED
    locked.version = locked.version + 1
    locked.save(update_fields=["status", "version", "updated_at"])
    _audit(user, "shift_publish", locked)
    return locked


@transaction.atomic
def cancel_shift(*, user, shift: Shift, expected_version: int) -> Shift:
    locked = Shift.objects.select_for_update().get(pk=shift.pk)
    if locked.version != expected_version:
        raise ShiftConflictError(
            "Směnu mezitím upravil někdo jiný. Obnovte stránku a zkuste znovu."
        )
    if locked.status == Shift.Status.CANCELLED:
        return locked
    locked.status = Shift.Status.CANCELLED
    locked.version = locked.version + 1
    locked.save(update_fields=["status", "version", "updated_at"])
    _audit(user, "shift_cancel", locked)
    return locked


def planned_net_minutes_for_employee_month(
    employee: Employee, year: int, month: int
) -> int:
    days = month_day_list(year, month)
    start = timezone.make_aware(
        datetime.combine(days[0], datetime.min.time()),
        timezone.get_current_timezone(),
    )
    end = timezone.make_aware(
        datetime.combine(days[-1] + timedelta(days=1), datetime.min.time()),
        timezone.get_current_timezone(),
    )
    total = 0
    qs = (
        Shift.objects.filter(
            employee=employee,
            status=Shift.Status.PUBLISHED,
            starts_at__lt=end,
            ends_at__gt=start,
        )
        .select_related("shift_type")
    )
    for shift in qs:
        total += shift.planned_net_minutes()
    return total


def monday_of_week(day: date) -> date:
    """Pondělí kalendářního týdne obsahujícího daný den (Po=0)."""
    return day - timedelta(days=day.weekday())


def workplace_overlapping_month(
    employee: Employee, month_start: date, month_end: date
) -> Workplace | None:
    """Primární pracoviště v měsíci (zpětná kompatibilita)."""
    return primary_workplace_for_month(employee, month_start, month_end)


def _workplace_on_day_from_assignments(assignments, day: date) -> Workplace | None:
    candidates = [
        asg
        for asg in assignments
        if asg.valid_from <= day
        and (asg.valid_to is None or asg.valid_to >= day)
    ]
    if not candidates:
        return None
    return max(candidates, key=lambda a: a.valid_from).workplace


def workplace_segments_in_month(
    employee: Employee, month_start: date, month_end: date
) -> list[dict]:
    """Intervaly pracoviště v měsíci včetně mezer bez přiřazení."""
    assignments = list(employee.workplace_assignments.all())
    segments: list[dict] = []
    current_wp: Workplace | None = None
    seg_start: date | None = None
    day = month_start
    while day <= month_end:
        wp = _workplace_on_day_from_assignments(assignments, day)
        if seg_start is None:
            seg_start = day
            current_wp = wp
        elif (wp.pk if wp else None) != (current_wp.pk if current_wp else None):
            segments.append(
                {
                    "workplace": current_wp,
                    "starts_on": seg_start,
                    "ends_on": day - timedelta(days=1),
                }
            )
            seg_start = day
            current_wp = wp
        day += timedelta(days=1)
    if seg_start is not None:
        segments.append(
            {
                "workplace": current_wp,
                "starts_on": seg_start,
                "ends_on": month_end,
            }
        )
    return segments


def primary_workplace_for_month(
    employee: Employee, month_start: date, month_end: date
) -> Workplace | None:
    """Pracoviště středu měsíce, jinak nejdelší pojmenovaný segment."""
    segments = workplace_segments_in_month(employee, month_start, month_end)
    if not segments:
        return None
    mid = month_start + timedelta(days=(month_end - month_start).days // 2)
    for seg in segments:
        if seg["starts_on"] <= mid <= seg["ends_on"] and seg["workplace"]:
            return seg["workplace"]
    named = [s for s in segments if s["workplace"]]
    if not named:
        return None

    def _length(seg: dict) -> int:
        return (seg["ends_on"] - seg["starts_on"]).days + 1

    return max(named, key=_length)["workplace"]


def format_workplace_segments_label(segments: list[dict]) -> str:
    """Popisek segmentů, např. Managment (1.–15.9.) · Jih (16.–30.9.)."""
    parts: list[str] = []
    for seg in segments:
        name = seg["workplace"].name if seg["workplace"] else "Bez pracoviště"
        start = seg["starts_on"]
        end = seg["ends_on"]
        if start == end:
            date_part = f"{start.day}.{start.month}."
        else:
            date_part = f"{start.day}.–{end.day}.{end.month}."
        parts.append(f"{name} ({date_part})")
    return " · ".join(parts)


def format_workplace_assignments_label(
    employee: Employee, month_start: date, month_end: date
) -> str:
    """Platnosti pracovišť z evidence zaměstnance překrývající měsíc.

    Např. Managment (od 01.10.2026) nebo Jih (01.09.2026–15.09.2026).
    """
    assignments = sorted(
        (
            asg
            for asg in employee.workplace_assignments.all()
            if asg.valid_from <= month_end
            and (asg.valid_to is None or asg.valid_to >= month_start)
        ),
        key=lambda a: a.valid_from,
    )
    parts: list[str] = []
    for asg in assignments:
        name = asg.workplace.name
        start = asg.valid_from.strftime("%d.%m.%Y")
        if asg.valid_to is None:
            parts.append(f"{name} (od {start})")
        else:
            end = asg.valid_to.strftime("%d.%m.%Y")
            parts.append(f"{name} ({start}–{end})")
    return " · ".join(parts)


def employment_covers_month(
    employee: Employee, month_start: date, month_end: date
) -> bool:
    """Aktivní pracovní vztah překrývá alespoň jeden den měsíce."""
    for emp in employee.employments.all():
        if not emp.is_active:
            continue
        if emp.started_on > month_end:
            continue
        if emp.ended_on is not None and emp.ended_on < month_start:
            continue
        return True
    return False


def filter_employees_with_employment_in_range(
    qs: QuerySet[Employee], date_from: date, date_to: date
) -> QuerySet[Employee]:
    """Aktivní zaměstnanci s aktivním Employment překrývajícím interval."""
    from django.db.models import Q

    return (
        qs.filter(
            is_active=True,
            employments__is_active=True,
            employments__started_on__lte=date_to,
        )
        .filter(
            Q(employments__ended_on__isnull=True)
            | Q(employments__ended_on__gte=date_from)
        )
        .distinct()
        .order_by("last_name", "first_name")
    )


def nearest_future_workplace_hint(
    employee: Employee, month_end: date
) -> str:
    """Nejbližší budoucí přiřazení po konci měsíce (pro muted text)."""
    future = [
        asg
        for asg in employee.workplace_assignments.all()
        if asg.valid_from > month_end
    ]
    if not future:
        return ""
    asg = min(future, key=lambda a: a.valid_from)
    return f"{asg.workplace.name} od {asg.valid_from:%d.%m.%Y}"


def build_month_matrix(*, user, year: int, month: int) -> dict:
    days = month_day_list(year, month)
    month_start = days[0]
    month_end = days[-1]
    holiday_map = holidays_for_year(year)
    employees = list(
        employees_visible_for_shift_plan(user).prefetch_related(
            Prefetch(
                "workplace_assignments",
                queryset=EmployeeWorkplace.objects.select_related("workplace").order_by(
                    "-valid_from"
                ),
            ),
            "employments",
        )
    )
    tz = timezone.get_current_timezone()
    range_start = timezone.make_aware(
        datetime.combine(days[0], datetime.min.time()), tz
    )
    range_end = timezone.make_aware(
        datetime.combine(days[-1] + timedelta(days=1), datetime.min.time()), tz
    )
    employee_ids = [e.pk for e in employees]
    shifts = (
        Shift.objects.filter(
            employee_id__in=employee_ids,
            starts_at__lt=range_end,
            ends_at__gt=range_start,
        )
        .exclude(status=Shift.Status.CANCELLED)
        .select_related("shift_type", "workplace", "employee")
    )
    # Pro ne-manažery jen publikované
    if not can_manage_shift_plan(user):
        shifts = shifts.filter(status=Shift.Status.PUBLISHED)

    cells: dict[tuple[int, date], list[Shift]] = {}
    for shift in shifts:
        local_day = timezone.localtime(shift.starts_at, tz).date()
        if local_day.year == year and local_day.month == month:
            cells.setdefault((shift.employee_id, local_day), []).append(shift)

    mid = days[14] if len(days) > 14 else days[0]
    unassigned_key = "Bez pracoviště"
    emp_meta: dict[int, dict] = {}
    groups: dict[str, list] = {}
    for emp in employees:
        has_employment = employment_covers_month(emp, month_start, month_end)
        if not has_employment:
            # Bez platného pracovního vztahu v měsíci neplánujeme
            continue
        primary = primary_workplace_for_month(emp, month_start, month_end)
        key = primary.name if primary else unassigned_key
        segments_label = format_workplace_assignments_label(
            emp, month_start, month_end
        )
        future_hint = ""
        if primary is None:
            future_hint = nearest_future_workplace_hint(emp, month_end)
        emp_meta[emp.pk] = {
            "workplace_name": key,
            "workplace_segments_label": segments_label,
            "workplace_future_hint": future_hint,
        }
        groups.setdefault(key, []).append(emp)

    rows = []
    for workplace_name in sorted(groups.keys(), key=lambda n: (n == unassigned_key, n)):
        for emp in sorted(groups[workplace_name], key=lambda e: (e.last_name, e.first_name)):
            day_cells = []
            planned = 0
            for day in days:
                day_shifts = sorted(
                    cells.get((emp.pk, day), []),
                    key=lambda s: s.starts_at,
                )
                for shift in day_shifts:
                    if shift.status == Shift.Status.PUBLISHED:
                        planned += shift.planned_net_minutes()
                codes = "+".join(s.display_code for s in day_shifts) if day_shifts else ""
                day_cells.append(
                    {
                        "day": day,
                        "shifts": day_shifts,
                        "codes": codes,
                        "can_add": len(day_shifts) < MAX_SHIFTS_PER_DAY,
                        "is_weekend": day.weekday() >= 5,
                        "is_holiday": day in holiday_map,
                    }
                )
            cal_fund = employee_month_fund(
                emp,
                year,
                month,
                mid=mid,
                cells=cells,
                holiday_map=holiday_map,
            )
            fund_minutes = cal_fund["fund_minutes"]
            delta = planned - fund_minutes
            meta = emp_meta[emp.pk]
            bal_list = balancing_summaries_for_month(emp, year, month)
            rows.append(
                {
                    "employee": emp,
                    "workplace_name": meta["workplace_name"],
                    "workplace_segments_label": meta["workplace_segments_label"],
                    "workplace_future_hint": meta["workplace_future_hint"],
                    "cells": day_cells,
                    "planned_minutes": planned,
                    "planned_label": format_hours(planned),
                    "fund": cal_fund,
                    "fund_delta_minutes": delta,
                    "fund_delta_label": format_hours(abs(delta)),
                    "fund_delta_short": delta < 0,
                    "fund_delta_over": delta > 0,
                    "fund_delta_ok": delta == 0,
                    "balancing": fund_summary_for_employee(emp, mid),
                    "balancing_list": bal_list,
                }
            )

    day_headers = [
        {
            "day": day,
            "weekday_label": WEEKDAY_LABELS_SHORT[day.weekday()],
            "is_holiday": day in holiday_map,
            "holiday_name": holiday_map.get(day, ""),
            "is_weekend": day.weekday() >= 5,
        }
        for day in days
    ]
    types = list(ShiftType.objects.filter(is_active=True).order_by("sort_order", "code"))
    return {
        "year": year,
        "month": month,
        "days": days,
        "day_headers": day_headers,
        "rows": rows,
        "shift_types": types,
        "can_edit": can_manage_shift_plan(user),
    }


def resolve_template_type(employee: Employee, day: date) -> ShiftType | None:
    asg = resolve_assignment_for_day(employee, day)
    if not asg or not asg.template_id or not asg.template.is_active:
        return None
    return asg.type_for_day(day)


def resolve_assignment_for_day(
    employee: Employee, day: date
) -> EmployeeScheduleAssignment | None:
    from django.db.models import Q

    return (
        EmployeeScheduleAssignment.objects.filter(
            employee=employee,
            is_active=True,
            valid_from__lte=day,
        )
        .filter(Q(valid_to__isnull=True) | Q(valid_to__gte=day))
        .select_related("template", "workplace")
        .order_by("-valid_from")
        .first()
    )


def active_balancing_period_for_employee(
    employee: Employee, day: date
) -> BalancingPeriod | None:
    from django.db.models import Q

    employment = employee.current_employment
    if not employment:
        return None
    profile = (
        WorkTimeProfile.objects.filter(
            employment=employment,
            is_active=True,
            valid_from__lte=day,
        )
        .filter(Q(valid_to__isnull=True) | Q(valid_to__gte=day))
        .order_by("-valid_from")
        .first()
    )
    if not profile:
        return None
    return (
        BalancingPeriod.objects.filter(
            profile=profile,
            kind=BalancingPeriod.Kind.SCHEDULE,
            starts_on__lte=day,
            ends_on__gte=day,
        )
        .order_by("-starts_on")
        .first()
    )


def planned_net_minutes_in_range(
    employee: Employee, start_day: date, end_day: date
) -> int:
    tz = timezone.get_current_timezone()
    start = timezone.make_aware(datetime.combine(start_day, datetime.min.time()), tz)
    end = timezone.make_aware(
        datetime.combine(end_day + timedelta(days=1), datetime.min.time()), tz
    )
    total = 0
    qs = (
        Shift.objects.filter(
            employee=employee,
            status=Shift.Status.PUBLISHED,
            starts_at__lt=end,
            ends_at__gt=start,
        )
        .select_related("shift_type")
    )
    for shift in qs:
        total += shift.planned_net_minutes()
    return total


def fund_summary_for_employee(employee: Employee, day: date) -> dict | None:
    period = active_balancing_period_for_employee(employee, day)
    if not period:
        return None
    planned = planned_net_minutes_in_range(
        employee, period.starts_on, period.ends_on
    )
    target = dynamic_balancing_target_minutes(period)
    return {
        "period": period,
        "planned_minutes": planned,
        "target_minutes": target,
        "stored_target_minutes": period.target_minutes,
        "planned_label": format_hours(planned),
        "target_label": format_hours(target),
        "delta_minutes": planned - target,
        "delta_label": format_hours(abs(planned - target)),
        "is_short": planned < target,
        "is_over": planned > target,
    }


def balancing_summaries_for_month(
    employee: Employee, year: int, month: int
) -> list[dict]:
    """Všechna vyrovnávací období překrývající měsíc (dynamický cíl)."""
    days = month_day_list(year, month)
    month_start, month_end = days[0], days[-1]
    employment = employee.current_employment
    if not employment:
        return []
    periods = (
        BalancingPeriod.objects.filter(
            profile__employment=employment,
            profile__is_active=True,
            kind=BalancingPeriod.Kind.SCHEDULE,
            starts_on__lte=month_end,
            ends_on__gte=month_start,
        )
        .select_related("profile")
        .order_by("starts_on")
    )
    summaries = []
    for period in periods:
        planned = planned_net_minutes_in_range(
            employee, period.starts_on, period.ends_on
        )
        target = dynamic_balancing_target_minutes(period)
        delta = planned - target
        summaries.append(
            {
                "period": period,
                "planned_minutes": planned,
                "target_minutes": target,
                "planned_label": format_hours(planned),
                "target_label": format_hours(target),
                "delta_minutes": delta,
                "delta_label": format_hours(abs(delta)),
                "is_short": delta < 0,
                "is_over": delta > 0,
                "label": (
                    f"{period.starts_on:%d.%m.}–{period.ends_on:%d.%m.} "
                    f"{format_hours(planned)}/{format_hours(target)} h"
                ),
            }
        )
    return summaries


def types_available_for_employee_day(employee: Employee, day: date) -> list[ShiftType]:
    """Unikátní typy ze šablony zaměstnance; jinak aktivní typy."""
    asg = resolve_assignment_for_day(employee, day)
    if asg and asg.template_id and asg.template.is_active:
        asg.template.ensure_slots()
        ids = list(
            asg.template.slots.exclude(shift_type__isnull=True)
            .values_list("shift_type_id", flat=True)
            .distinct()
        )
        if ids:
            return list(
                ShiftType.objects.filter(pk__in=ids, is_active=True).order_by(
                    "sort_order", "code"
                )
            )
    return list(
        ShiftType.objects.filter(is_active=True).order_by("sort_order", "code")
    )


def _day_has_shift_type(employee: Employee, day: date, shift_type: ShiftType) -> bool:
    return _shifts_on_calendar_day(employee, day).filter(
        shift_type=shift_type
    ).exists()


def workplace_for_employee_day(employee: Employee, day: date) -> Workplace | None:
    """Pracoviště ze šablonového přiřazení, jinak překryv EmployeeWorkplace s dnem."""
    asg = resolve_assignment_for_day(employee, day)
    if asg:
        return asg.workplace
    # Načti přiřazení seřazená od nejnovějšího valid_from
    assignments = list(
        EmployeeWorkplace.objects.filter(employee=employee)
        .select_related("workplace")
        .order_by("-valid_from")
    )
    for asg_wp in assignments:
        if asg_wp.valid_from > day:
            continue
        if asg_wp.valid_to is not None and asg_wp.valid_to < day:
            continue
        return asg_wp.workplace
    return None


def _generation_horizon_for_range(
    employee: Employee, date_from: date, date_to: date
) -> tuple[date, date]:
    """Omezí interval aktivním vyrovnávacím obdobím, pokud existuje."""
    mid = date_from + timedelta(days=(date_to - date_from).days // 2)
    period = active_balancing_period_for_employee(employee, mid)
    if period:
        start = max(date_from, period.starts_on)
        end = min(date_to, period.ends_on)
        if end >= start:
            return start, end
    return date_from, date_to


@transaction.atomic
def generate_shifts_from_templates(
    *,
    user,
    date_from: date,
    date_to: date,
    template: ScheduleTemplate,
    workplace: Workplace,
    cycle_anchor_date: date | None = None,
    employee_ids: list[int] | None = None,
) -> dict:
    """Vyplní dny podle zvolené šablony běhu; nepřepisuje existující typy."""
    if not can_manage_shift_plan(user):
        raise PermissionError("Nemáte oprávnění generovat plán směn.")
    if date_to < date_from:
        raise ValidationError("Konec intervalu musí být stejný nebo pozdější než začátek.")
    if not template.is_active:
        raise ValidationError("Šablona není aktivní.")
    anchor = cycle_anchor_date or monday_of_week(date_from)
    holiday_years: set[int] = set()
    holiday_map: dict[date, str] = {}
    employees = employees_visible_for_shift_plan(user)
    if employee_ids is not None:
        employees = employees.filter(pk__in=employee_ids)
    employees = list(employees)
    created = 0
    skipped_existing = 0
    skipped_holiday = 0
    skipped_empty = 0
    skipped_no_employment = 0

    for emp in employees:
        start, end = _generation_horizon_for_range(emp, date_from, date_to)
        day = start
        while day <= end:
            if day.year not in holiday_years:
                holiday_map.update(holidays_for_year(day.year))
                holiday_years.add(day.year)
            if employment_for_day(emp, day) is None:
                skipped_no_employment += 1
                day += timedelta(days=1)
                continue
            shift_type = template.type_for_date(day, anchor)
            if not shift_type:
                skipped_empty += 1
                day += timedelta(days=1)
                continue
            if day in holiday_map and not shift_type.applies_on_holiday:
                skipped_holiday += 1
                day += timedelta(days=1)
                continue
            if _day_has_shift_type(emp, day, shift_type):
                skipped_existing += 1
                day += timedelta(days=1)
                continue
            try:
                assign_shift_cell(
                    user=user,
                    employee=emp,
                    workplace=workplace,
                    day=day,
                    shift_type=shift_type,
                    publish=True,
                )
            except (ShiftConflictError, ValidationError):
                skipped_existing += 1
                day += timedelta(days=1)
                continue
            created += 1
            day += timedelta(days=1)

    return {
        "created": created,
        "skipped_existing": skipped_existing,
        "skipped_holiday": skipped_holiday,
        "skipped_empty": skipped_empty,
        "skipped_no_employment": skipped_no_employment,
    }


def generate_month_from_templates(
    *,
    user,
    year: int,
    month: int,
    template: ScheduleTemplate,
    workplace: Workplace,
    cycle_anchor_date: date | None = None,
    employee_ids: list[int] | None = None,
) -> dict:
    days = month_day_list(year, month)
    return generate_shifts_from_templates(
        user=user,
        date_from=days[0],
        date_to=days[-1],
        template=template,
        workplace=workplace,
        cycle_anchor_date=cycle_anchor_date or monday_of_week(days[0]),
        employee_ids=employee_ids,
    )
