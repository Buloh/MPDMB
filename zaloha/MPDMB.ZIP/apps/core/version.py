"""Název a verze aplikace SYNERA."""

APP_NAME = "SYNERA"
APP_TITLE = "SYNERA"
APP_TAGLINE = "Správa zaměstnanců a provozu parkovacích domů"
__version__ = "0.6.31"
